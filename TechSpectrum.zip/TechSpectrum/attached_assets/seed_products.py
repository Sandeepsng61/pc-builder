from pymongo import MongoClient

client = MongoClient("mongodb://localhost:27017")
db = client['your_database_name']
products = db.products

# Example products
sample_products = [
    {
        "name": "Intel Core i5 12400F",
        "category": "processor",
        "image_url": "https://via.placeholder.com/300x200?text=i5+12400F",
        "price": 14500,
        "cores": 6,
        "threads": 12
    },
    {
        "name": "ASUS Prime B660M-K D4",
        "category": "motherboard",
        "image_url": "https://via.placeholder.com/300x200?text=B660M-K",
        "price": 9000,
        "socket": "LGA1700",
        "chipset": "B660"
    },
    {
        "name": "NVIDIA RTX 3060",
        "category": "gpu",
        "image_url": "https://via.placeholder.com/300x200?text=RTX+3060",
        "price": 28000,
        "vram": "12GB",
        "brand": "NVIDIA"
    },
    {
        "name": "Corsair Vengeance 16GB DDR4",
        "category": "ram",
        "image_url": "https://via.placeholder.com/300x200?text=16GB+DDR4",
        "price": 3500,
        "size": "16GB",
        "type": "DDR4"
    },
    {
        "name": "WD Blue 1TB SSD NVMe",
        "category": "ssd",
        "image_url": "https://via.placeholder.com/300x200?text=1TB+SSD",
        "price": 5000,
        "capacity": "1TB",
        "type": "NVMe"
    }
]

# Insert data
products.insert_many(sample_products)
print("Sample products inserted successfully!")
