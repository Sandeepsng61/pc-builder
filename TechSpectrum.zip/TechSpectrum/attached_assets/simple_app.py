from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from zoneinfo import ZoneInfo
import pytz
import os
import datetime
import logging
import uuid
import json
import stripe

# Configure logging
logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "supersecret123")  # Use env var in prod
CORS(app)

# Configure Stripe
stripe.api_key = os.environ.get('STRIPE_SECRET_KEY')

# Configure database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL", "sqlite:///pc_assembler.db")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)

# Define models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Kolkata")))
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
        
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(128), nullable=False)
    price = db.Column(db.Float, nullable=False)
    category = db.Column(db.String(64), nullable=False)
    description = db.Column(db.Text)
    image_url = db.Column(db.String(256))
    specs = db.Column(db.JSON)
    stock = db.Column(db.Integer, default=10)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Kolkata")))

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.String(16), unique=True, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    name = db.Column(db.String(128), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    address = db.Column(db.Text, nullable=False)
    payment_method = db.Column(db.String(32), nullable=False)
    total_price = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(32), default="pending")
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Kolkata")))
    
    # Relationship
    user = db.relationship('User', backref=db.backref('orders', lazy=True))

class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, default=1)
    price = db.Column(db.Float, nullable=False)
    
    # Relationships
    order = db.relationship('Order', backref=db.backref('items', lazy=True))
    product = db.relationship('Product')

class Wishlist(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(ZoneInfo("Asia/Kolkata")))
    
    # Relationships
    user = db.relationship('User', backref=db.backref('wishlist_items', lazy=True))
    product = db.relationship('Product')

# Initialize database
with app.app_context():
    db.create_all()
    
    # Force reset products to ensure components are available
    Product.query.delete()
    
    # Add sample data
    # Create a demo user if it doesn't exist
    demo_user = User.query.filter_by(username="demo").first()
    if not demo_user:
        demo_user = User(username="demo", email="demo@example.com")
        demo_user.set_password("password")
        db.session.add(demo_user)
    
    # Create some products
    products = [
        # Intel Gaming PCs
        Product(
                name="Intel Gaming PC - Ultimate Edition",
                price=1299.99,
                category="prebuilt",
                description="High-performance gaming PC with Intel Core i7 processor",
                image_url="https://via.placeholder.com/300x200?text=Intel+Gaming+PC",
                specs={
                    "cpu": "Intel Core i7-12700K",
                    "ram": "32GB DDR4 3200MHz",
                    "storage": "1TB NVMe SSD",
                    "gpu": "NVIDIA RTX 3070"
                }
            ),
            Product(
                name="Intel Pro Gaming Rig",
                price=1799.99,
                category="prebuilt",
                description="Professional-grade gaming PC with top-tier Intel CPU",
                image_url="https://via.placeholder.com/300x200?text=Intel+Pro+Gaming",
                specs={
                    "cpu": "Intel Core i9-12900K",
                    "ram": "64GB DDR5 4800MHz",
                    "storage": "2TB NVMe SSD",
                    "gpu": "NVIDIA RTX 3080 Ti"
                }
            ),
            Product(
                name="Intel Budget Gamer",
                price=899.99,
                category="prebuilt",
                description="Affordable gaming PC with Intel Core i5 processor",
                image_url="https://via.placeholder.com/300x200?text=Intel+Budget+PC",
                specs={
                    "cpu": "Intel Core i5-12400F",
                    "ram": "16GB DDR4 3000MHz",
                    "storage": "500GB NVMe SSD + 1TB HDD",
                    "gpu": "NVIDIA RTX 3060"
                }
            ),
            
            # AMD Gaming PCs
            Product(
                name="AMD Gaming PC - Pro Series",
                price=1199.99,
                category="prebuilt",
                description="High-performance gaming PC with AMD Ryzen processor",
                image_url="https://via.placeholder.com/300x200?text=AMD+Gaming+PC",
                specs={
                    "cpu": "AMD Ryzen 7 5800X",
                    "ram": "32GB DDR4 3600MHz",
                    "storage": "1TB NVMe SSD",
                    "gpu": "AMD Radeon RX 6800 XT"
                }
            ),
            Product(
                name="AMD Threadripper Workstation",
                price=2499.99,
                category="prebuilt",
                description="Extreme performance workstation with AMD Threadripper CPU",
                image_url="https://via.placeholder.com/300x200?text=AMD+Workstation",
                specs={
                    "cpu": "AMD Threadripper 3970X",
                    "ram": "128GB DDR4 3200MHz",
                    "storage": "4TB NVMe SSD RAID",
                    "gpu": "AMD Radeon Pro W6800"
                }
            ),
            Product(
                name="AMD Budget Gaming PC",
                price=799.99,
                category="prebuilt",
                description="Affordable gaming PC with AMD Ryzen 5 processor",
                image_url="https://via.placeholder.com/300x200?text=AMD+Budget+PC",
                specs={
                    "cpu": "AMD Ryzen 5 5600X",
                    "ram": "16GB DDR4 3200MHz",
                    "storage": "500GB NVMe SSD + 1TB HDD",
                    "gpu": "AMD Radeon RX 6600 XT"
                }
            ),
            Product(
                name="PlayStation 5",
                price=499.99,
                category="console",
                description="Next-generation gaming console from Sony",
                image_url="https://via.placeholder.com/300x200?text=PlayStation+5",
                specs={
                    "cpu": "8-core AMD Zen 2",
                    "gpu": "AMD RDNA 2",
                    "storage": "825GB SSD"
                }
            ),
            Product(
                name="Xbox Series X",
                price=499.99,
                category="console",
                description="Next-generation gaming console from Microsoft",
                image_url="https://via.placeholder.com/300x200?text=Xbox+Series+X",
                specs={
                    "cpu": "8-core AMD Zen 2",
                    "gpu": "AMD RDNA 2",
                    "storage": "1TB SSD"
                }
            )
    ]
    
    # Add individual components
    components = [
        # CPUs
        Product(
                name="Intel Core i5-13600K",
                price=299.99,
                category="cpu",
                description="12 cores (6P + 6E), 20 threads, up to 5.1 GHz",
                image_url="https://via.placeholder.com/300x200?text=Intel+i5+13600K",
                specs={
                    "brand": "Intel",
                    "cores": 12,
                    "threads": 20,
                    "base_clock": "3.5 GHz",
                    "boost_clock": "5.1 GHz",
                    "socket": "LGA 1700",
                    "tdp": "125W"
                },
                stock=15
            ),
            Product(
                name="AMD Ryzen 7 7800X3D",
                price=449.99,
                category="cpu",
                description="8 cores, 16 threads, up to 5.0 GHz with 3D V-Cache",
                image_url="https://via.placeholder.com/300x200?text=AMD+Ryzen+7+7800X3D",
                specs={
                    "brand": "AMD",
                    "cores": 8,
                    "threads": 16,
                    "base_clock": "4.2 GHz",
                    "boost_clock": "5.0 GHz",
                    "socket": "AM5",
                    "tdp": "120W",
                    "cache": "96MB"
                },
                stock=10
            ),
            Product(
                name="AMD Ryzen 5 5600G",
                price=189.99,
                category="cpu",
                description="6 cores, 12 threads, up to 4.4 GHz with integrated Radeon graphics",
                image_url="https://via.placeholder.com/300x200?text=AMD+Ryzen+5+5600G",
                specs={
                    "brand": "AMD",
                    "cores": 6,
                    "threads": 12,
                    "base_clock": "3.9 GHz",
                    "boost_clock": "4.4 GHz",
                    "socket": "AM4",
                    "tdp": "65W",
                    "integrated_graphics": "Radeon Vega 7"
                },
                stock=20
            ),
            
            # GPUs
            Product(
                name="NVIDIA RTX 4070",
                price=599.99,
                category="gpu",
                description="12GB GDDR6X, ray tracing, DLSS 3.0",
                image_url="https://via.placeholder.com/300x200?text=NVIDIA+RTX+4070",
                specs={
                    "brand": "NVIDIA",
                    "memory": "12GB GDDR6X",
                    "memory_bus": "192-bit",
                    "cuda_cores": "5888",
                    "boost_clock": "2.48 GHz",
                    "power": "200W"
                },
                stock=8
            ),
            Product(
                name="AMD Radeon RX 7800 XT",
                price=549.99,
                category="gpu",
                description="16GB GDDR6, ray tracing, FSR 3.0",
                image_url="https://via.placeholder.com/300x200?text=AMD+RX+7800+XT",
                specs={
                    "brand": "AMD",
                    "memory": "16GB GDDR6",
                    "memory_bus": "256-bit",
                    "stream_processors": "3840",
                    "boost_clock": "2.43 GHz",
                    "power": "263W"
                },
                stock=5
            ),
            
            # Motherboards
            Product(
                name="ASUS ROG Strix Z790-E Gaming WiFi",
                price=399.99,
                category="motherboard",
                description="Intel Z790 ATX motherboard with DDR5, PCIe 5.0, WiFi 6E",
                image_url="https://via.placeholder.com/300x200?text=ASUS+ROG+Z790",
                specs={
                    "brand": "ASUS",
                    "chipset": "Intel Z790",
                    "socket": "LGA 1700",
                    "form_factor": "ATX",
                    "memory_slots": "4 x DDR5",
                    "max_memory": "128GB",
                    "pcie": "PCIe 5.0 x16, PCIe 4.0 x16",
                    "m2_slots": "4",
                    "sata_ports": "6",
                    "wifi": "WiFi 6E",
                    "bluetooth": "5.3"
                },
                stock=12
            ),
            Product(
                name="MSI MAG B650 TOMAHAWK WiFi",
                price=249.99,
                category="motherboard",
                description="AMD B650 ATX motherboard with DDR5, PCIe 5.0, WiFi 6",
                image_url="https://via.placeholder.com/300x200?text=MSI+B650+TOMAHAWK",
                specs={
                    "brand": "MSI",
                    "chipset": "AMD B650",
                    "socket": "AM5",
                    "form_factor": "ATX",
                    "memory_slots": "4 x DDR5",
                    "max_memory": "128GB",
                    "pcie": "PCIe 5.0 x16, PCIe 4.0 x16",
                    "m2_slots": "3",
                    "sata_ports": "6",
                    "wifi": "WiFi 6",
                    "bluetooth": "5.2"
                },
                stock=9
            ),
            
            # Memory (RAM)
            Product(
                name="Corsair Vengeance RGB 32GB (2x16GB) DDR5-6000",
                price=189.99,
                category="ram",
                description="RGB DDR5 memory with high performance and XMP 3.0 support",
                image_url="https://via.placeholder.com/300x200?text=Corsair+DDR5+RAM",
                specs={
                    "brand": "Corsair",
                    "capacity": "32GB (2x16GB)",
                    "type": "DDR5",
                    "speed": "6000MHz",
                    "cas_latency": "CL36",
                    "voltage": "1.35V",
                    "rgb": "Yes"
                },
                stock=25
            ),
            Product(
                name="G.Skill Trident Z5 RGB 64GB (2x32GB) DDR5-5600",
                price=289.99,
                category="ram",
                description="High-capacity RGB DDR5 memory for workstations and high-end gaming",
                image_url="https://via.placeholder.com/300x200?text=G.Skill+DDR5+RAM",
                specs={
                    "brand": "G.Skill",
                    "capacity": "64GB (2x32GB)",
                    "type": "DDR5",
                    "speed": "5600MHz",
                    "cas_latency": "CL40",
                    "voltage": "1.2V",
                    "rgb": "Yes"
                },
                stock=8
            ),
            
            # Storage
            Product(
                name="Samsung 990 PRO 2TB NVMe SSD",
                price=249.99,
                category="storage",
                description="PCIe 4.0 NVMe SSD with up to 7,450 MB/s read speeds",
                image_url="https://via.placeholder.com/300x200?text=Samsung+990+PRO",
                specs={
                    "brand": "Samsung",
                    "capacity": "2TB",
                    "type": "NVMe M.2",
                    "interface": "PCIe 4.0 x4",
                    "read_speed": "7,450 MB/s",
                    "write_speed": "6,900 MB/s",
                    "endurance": "1200 TBW"
                },
                stock=15
            ),
            Product(
                name="Crucial MX500 1TB SATA SSD",
                price=89.99,
                category="storage",
                description="Reliable SATA SSD with AES 256-bit encryption",
                image_url="https://via.placeholder.com/300x200?text=Crucial+MX500",
                specs={
                    "brand": "Crucial",
                    "capacity": "1TB",
                    "type": "SATA SSD",
                    "interface": "SATA III",
                    "read_speed": "560 MB/s",
                    "write_speed": "510 MB/s",
                    "endurance": "360 TBW"
                },
                stock=30
            ),
            
            # Power Supplies
            Product(
                name="Corsair RM850x 850W 80+ Gold",
                price=149.99,
                category="psu",
                description="Fully modular PSU with 80+ Gold efficiency and zero RPM fan mode",
                image_url="https://via.placeholder.com/300x200?text=Corsair+RM850x",
                specs={
                    "brand": "Corsair",
                    "wattage": "850W",
                    "efficiency": "80+ Gold",
                    "modular": "Fully Modular",
                    "fan_size": "135mm",
                    "connectors": "2x EPS, 4x PCIe, 10x SATA, 4x Molex"
                },
                stock=18
            ),
            Product(
                name="EVGA SuperNOVA 1000 G6 1000W 80+ Gold",
                price=189.99,
                category="psu",
                description="High-wattage modular PSU with eco mode and 10-year warranty",
                image_url="https://via.placeholder.com/300x200?text=EVGA+SuperNOVA+1000+G6",
                specs={
                    "brand": "EVGA",
                    "wattage": "1000W",
                    "efficiency": "80+ Gold",
                    "modular": "Fully Modular",
                    "fan_size": "135mm",
                    "connectors": "2x EPS, 6x PCIe, 12x SATA, 4x Molex"
                },
                stock=10
            ),
            
            # Cases
            Product(
                name="Corsair 5000D Airflow ATX Mid Tower",
                price=159.99,
                category="case",
                description="High airflow ATX case with excellent cable management",
                image_url="https://via.placeholder.com/300x200?text=Corsair+5000D",
                specs={
                    "brand": "Corsair",
                    "form_factor": "Mid Tower",
                    "motherboard_support": "ATX, Micro-ATX, Mini-ITX",
                    "dimensions": "520 x 245 x 520mm",
                    "included_fans": "2x 120mm AirGuide",
                    "max_fans": "10",
                    "radiator_support": "Top: 360mm, Front: 360mm, Side: 360mm",
                    "drive_bays": "2x 2.5\", 4x 3.5\"",
                    "i/o_ports": "1x USB 3.1 Type-C, 2x USB 3.0, Audio"
                },
                stock=7
            ),
            Product(
                name="Lian Li O11 Dynamic EVO",
                price=179.99,
                category="case",
                description="Versatile dual-chamber case with tempered glass panels",
                image_url="https://via.placeholder.com/300x200?text=Lian+Li+O11+Dynamic",
                specs={
                    "brand": "Lian Li",
                    "form_factor": "Mid Tower",
                    "motherboard_support": "E-ATX, ATX, Micro-ATX, Mini-ITX",
                    "dimensions": "465 x 285 x 459mm",
                    "included_fans": "None",
                    "max_fans": "10",
                    "radiator_support": "Top: 360mm, Side: 360mm, Bottom: 360mm",
                    "drive_bays": "6x 2.5\", 4x 3.5\"",
                    "i/o_ports": "1x USB 3.1 Type-C, 2x USB 3.0, Audio"
                },
                stock=5
            ),
            
            # CPU Coolers
            Product(
                name="Noctua NH-D15 Chromax.Black",
                price=109.99,
                category="cpu_cooler",
                description="Dual-tower air cooler with exceptional performance and quiet operation",
                image_url="https://via.placeholder.com/300x200?text=Noctua+NH-D15",
                specs={
                    "brand": "Noctua",
                    "type": "Air Cooler",
                    "fan_size": "2x 140mm NF-A15",
                    "dimensions": "165 x 150 x 161mm",
                    "noise_level": "24.6 dB(A)",
                    "compatibility": "Intel: LGA1700, LGA1200, LGA115x; AMD: AM5, AM4"
                },
                stock=12
            ),
            Product(
                name="NZXT Kraken X73 RGB 360mm AIO",
                price=219.99,
                category="cpu_cooler",
                description="360mm all-in-one liquid cooler with RGB lighting",
                image_url="https://via.placeholder.com/300x200?text=NZXT+Kraken+X73",
                specs={
                    "brand": "NZXT",
                    "type": "Liquid Cooler (AIO)",
                    "radiator_size": "360mm",
                    "fan_size": "3x 120mm RGB",
                    "noise_level": "21-36 dB(A)",
                    "compatibility": "Intel: LGA1700, LGA1200, LGA115x; AMD: AM5, AM4"
                },
                stock=6
            )
    ]
    
    for product in products + components:
        db.session.add(product)
        
    db.session.commit()

# Helper Functions
def generate_order_id():
    return f"ORD-{uuid.uuid4().hex[:8].upper()}"

# Routes
@app.route('/')
def index():
    featured_products = Product.query.limit(8).all()
    return render_template('index.html', featured_parts=featured_products)

@app.route('/home')
def home():
    return redirect(url_for('index'))

# Authentication Routes
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            session['user'] = user.username
            session['user_id'] = user.id
            flash('Login successful!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password.', 'danger')
    
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        
        # Validation
        if password != confirm_password:
            flash('Passwords do not match.', 'danger')
            return render_template('signup.html')
        
        if User.query.filter_by(username=username).first():
            flash('Username already exists.', 'danger')
        elif User.query.filter_by(email=email).first():
            flash('Email already registered.', 'danger')
        else:
            new_user = User(username=username, email=email)
            new_user.set_password(password)
            db.session.add(new_user)
            db.session.commit()
            
            flash('Signup successful! Please log in.', 'success')
            return redirect(url_for('login'))
    
    return render_template('signup.html')

@app.route('/logout')
def logout():
    session.pop('user', None)
    session.pop('user_id', None)
    session.pop('cart', None)
    flash('Logged out successfully.', 'info')
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if 'user' in session:
        orders = []
        if 'user_id' in session:
            user_id = session['user_id']
            orders = Order.query.filter_by(user_id=user_id).order_by(Order.created_at.desc()).all()
        
        return render_template('dashboard.html', 
                              username=session['user'], 
                              orders=orders)
    else:
        flash("Please login first!", "warning")
        return redirect(url_for('login'))

# Product Routes
@app.route('/prebuiltpc')
def prebuiltpc():
    prebuilt_pcs = Product.query.filter_by(category="prebuilt").all()
    return render_template('prebuiltpc.html', prebuilt_pcs=prebuilt_pcs)

@app.route('/intel-pc')
def intel_pc():
    # For simplicity, we'll just filter on name containing "Intel"
    intel_pcs = Product.query.filter(Product.name.like('%Intel%')).all()
    return render_template('intel_pc.html', intel_pcs=intel_pcs)

@app.route('/amd-pc')
def amd_pc():
    # For simplicity, we'll just filter on name containing "AMD"
    amd_pcs = Product.query.filter(Product.name.like('%AMD%')).all()
    return render_template('amd_pc.html', amd_pcs=amd_pcs)

@app.route('/gaming_console')
def gaming_console():
    consoles = Product.query.filter_by(category="console").all()
    return render_template('gaming_console.html', consoles=consoles)

# Individual Component Category Routes
@app.route('/components/cpu')
def cpu_components():
    products = Product.query.filter_by(category="cpu").all()
    return render_template('components.html', 
                          products=products, 
                          category_name="Processors (CPU)",
                          category="cpu")

@app.route('/components/gpu')
def gpu_components():
    products = Product.query.filter_by(category="gpu").all()
    return render_template('components.html', 
                          products=products, 
                          category_name="Graphics Cards (GPU)",
                          category="gpu")

@app.route('/components/motherboard')
def motherboard_components():
    products = Product.query.filter_by(category="motherboard").all()
    return render_template('components.html', 
                          products=products, 
                          category_name="Motherboards",
                          category="motherboard")

@app.route('/components/ram')
def ram_components():
    products = Product.query.filter_by(category="ram").all()
    return render_template('components.html', 
                          products=products, 
                          category_name="Memory (RAM)",
                          category="ram")

@app.route('/components/storage')
def storage_components():
    products = Product.query.filter_by(category="storage").all()
    return render_template('components.html', 
                          products=products, 
                          category_name="Storage Devices",
                          category="storage")

@app.route('/components/psu')
def psu_components():
    products = Product.query.filter_by(category="psu").all()
    return render_template('components.html', 
                          products=products, 
                          category_name="Power Supplies",
                          category="psu")

@app.route('/components/case')
def case_components():
    products = Product.query.filter_by(category="case").all()
    return render_template('components.html', 
                          products=products, 
                          category_name="Computer Cases",
                          category="case")

@app.route('/components/cpu_cooler')
def cpu_cooler_components():
    products = Product.query.filter_by(category="cpu_cooler").all()
    return render_template('components.html', 
                          products=products, 
                          category_name="CPU Coolers",
                          category="cpu_cooler")

@app.route('/custom_pc_builder')
def custom_pc_builder():
    return render_template('custom_pc_builder.html')

@app.route('/save_custom_pc', methods=['POST'])
def save_custom_pc():
    if request.method == 'POST':
        # Process the custom PC configuration
        pc_name = request.form.get('pc_build_name', 'Custom PC Build')
        
        # Get all the selected components
        cpu_model = request.form.get('cpu_model')
        motherboard_model = request.form.get('motherboard_model')
        ram_capacity = request.form.get('ram_capacity')
        ram_speed = request.form.get('ram_speed')
        storage_capacity = request.form.get('storage_capacity')
        gpu_model = request.form.get('gpu_model')
        psu_wattage = request.form.get('psu_wattage')
        psu_certification = request.form.get('psu_certification')
        case_model = request.form.get('case_model')
        
        # Optional components
        include_cpu_cooler = 'include_cpu_cooler' in request.form
        include_case_fans = 'include_case_fans' in request.form
        include_wifi = 'include_wifi' in request.form
        include_windows = 'include_windows' in request.form
        
        # Create a custom PC product
        total_price = float(request.form.get('total_price', 0).replace('$', ''))
        
        # Build the component list for the specs
        specs = {}
        
        # Check if we have an APU (CPU with integrated graphics)
        is_apu = False
        
        # CPU
        if cpu_model:
            cpu_brand = request.form.get('cpu_brand', '')
            # Check if it's an APU based on model numbers
            if ((cpu_brand == 'intel' and not cpu_model.endswith('f')) or 
                (cpu_brand == 'amd' and cpu_model.endswith('g'))):
                is_apu = True
                specs['cpu'] = f"{cpu_brand.upper()} {cpu_model} (with integrated graphics)"
            else:
                specs['cpu'] = f"{cpu_brand.upper()} {cpu_model}"
        
        # Motherboard
        if motherboard_model:
            motherboard_brand = request.form.get('motherboard_brand', '')
            specs['motherboard'] = f"{motherboard_brand.upper()} {motherboard_model}"
        
        # RAM
        if ram_capacity and ram_speed:
            specs['ram'] = f"{ram_capacity.upper()} {ram_speed.upper()}"
        
        # Storage
        if storage_capacity:
            storage_type = request.form.get('storage_type', '')
            if storage_type == 'sata_ssd':
                specs['storage'] = f"SATA SSD {storage_capacity}"
            elif storage_type == 'nvme_ssd':
                specs['storage'] = f"NVMe SSD {storage_capacity}"
            elif storage_type == 'hdd':
                specs['storage'] = f"HDD {storage_capacity}"
            else:
                specs['storage'] = storage_capacity
        
        # GPU (optional for APUs)
        if gpu_model:
            gpu_brand = request.form.get('gpu_brand', '')
            specs['gpu'] = f"{gpu_brand.upper()} {gpu_model}"
        elif is_apu:
            specs['gpu'] = "Using integrated graphics from CPU"
        
        # PSU
        if psu_wattage and psu_certification:
            specs['psu'] = f"{psu_wattage.upper()} {psu_certification.replace('_', ' ').upper()}"
        
        # Case
        if case_model:
            case_size = request.form.get('case_size', '')
            specs['case'] = f"{case_size.replace('_', ' ').title()} {case_model}"
        
        # Add optional components to specs
        optionals = []
        if include_cpu_cooler:
            optionals.append("CPU Cooler")
        if include_case_fans:
            optionals.append("Extra Case Fans")
        if include_wifi:
            optionals.append("Wi-Fi Card")
        if include_windows:
            optionals.append("Windows OS")
        
        if optionals:
            specs['optionals'] = ", ".join(optionals)
        
        # Create a new custom PC product
        custom_pc = Product(
            name=pc_name if pc_name else "Custom PC Build",
            price=total_price,
            category="custom",
            description="Custom built PC with user-selected components",
            image_url="https://via.placeholder.com/300x200?text=Custom+PC",
            specs=specs,
            stock=1
        )
        
        # Add to database
        db.session.add(custom_pc)
        db.session.commit()
        
        # Add to session cart
        if 'cart' not in session:
            session['cart'] = []
        
        session['cart'].append(str(custom_pc.id))
        session.modified = True
        
        flash(f'Your custom PC "{pc_name}" has been added to cart!', 'success')
        return redirect(url_for('cart'))
    
    return redirect(url_for('custom_pc_builder'))

# Cart Routes
@app.route('/cart')
def cart():
    cart_items = []
    total_price = 0
    
    if 'cart' in session and session['cart']:
        for item_id in session['cart']:
            product = Product.query.get(item_id)
            if product:
                cart_items.append(product)
                total_price += product.price
    
    return render_template('cart.html', cart_items=cart_items, total_price=total_price)

@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    item_id = request.form.get('item_id')
    
    if not item_id:
        flash("Invalid item", "danger")
        return redirect(request.referrer or url_for('index'))
    
    if 'cart' not in session:
        session['cart'] = []
    
    if item_id not in session['cart']:
        session['cart'].append(item_id)
        session.modified = True
        flash("Item added to cart!", "success")
    else:
        flash("Item already in cart!", "warning")
    
    return redirect(request.referrer or url_for('index'))

@app.route('/remove_from_cart', methods=['POST'])
def remove_from_cart():
    item_id = request.form.get('item_id')
    
    if 'cart' in session and item_id in session['cart']:
        session['cart'].remove(item_id)
        session.modified = True
        flash("Item removed from cart!", "success")
    
    return redirect(url_for('cart'))

@app.route('/clear_cart', methods=['POST'])
def clear_cart():
    session.pop('cart', None)
    flash("Cart has been cleared!", "success")
    return redirect(url_for('cart'))

# Wishlist Routes
@app.route('/wishlist')
def wishlist():
    if 'user' in session and 'user_id' in session:
        user_id = session['user_id']
        wishlist_items = db.session.query(Product).join(Wishlist).filter(Wishlist.user_id == user_id).all()
        return render_template('wishlist.html', wishlist_items=wishlist_items)
    else:
        flash('Please login to view your wishlist.', 'warning')
        return redirect(url_for('login'))

@app.route('/add_to_wishlist', methods=['POST'])
def add_to_wishlist():
    if 'user' in session and 'user_id' in session:
        user_id = session['user_id']
        item_id = request.form.get('item_id')
        
        if not item_id:
            flash("Invalid item", "danger")
            return redirect(request.referrer or url_for('index'))
        
        # Check if the item exists
        product = Product.query.get(item_id)
        if not product:
            flash("Item not found", "danger")
            return redirect(request.referrer or url_for('index'))
        
        # Check if already in wishlist
        existing_wishlist_item = Wishlist.query.filter_by(user_id=user_id, product_id=item_id).first()
        if not existing_wishlist_item:
            wishlist_item = Wishlist(user_id=user_id, product_id=item_id)
            db.session.add(wishlist_item)
            db.session.commit()
            flash('Item added to your wishlist!', 'success')
        else:
            flash('Item is already in your wishlist!', 'warning')
        
        return redirect(request.referrer or url_for('index'))
    else:
        flash('Please login to add items to your wishlist.', 'warning')
        return redirect(url_for('login'))

@app.route('/remove_from_wishlist', methods=['POST'])
def remove_from_wishlist():
    if 'user' in session and 'user_id' in session:
        user_id = session['user_id']
        item_id = request.form.get('item_id')
        
        if not item_id:
            flash("Invalid item", "danger")
            return redirect(url_for('wishlist'))
        
        wishlist_item = Wishlist.query.filter_by(user_id=user_id, product_id=item_id).first()
        if wishlist_item:
            db.session.delete(wishlist_item)
            db.session.commit()
            flash('Item removed from your wishlist!', 'success')
        
        return redirect(url_for('wishlist'))
    else:
        flash('Please login to manage your wishlist.', 'warning')
        return redirect(url_for('login'))

# Checkout and Orders
@app.route('/checkout')
def checkout():
    if 'user' not in session:
        flash('Please login to checkout.', 'warning')
        return redirect(url_for('login'))
    
    if 'cart' not in session or not session['cart']:
        flash('Your cart is empty.', 'warning')
        return redirect(url_for('cart'))
    
    cart_items = []
    total_price = 0
    
    for item_id in session['cart']:
        product = Product.query.get(item_id)
        if product:
            cart_items.append(product)
            total_price += product.price
    
    order_id = generate_order_id()
    
    return render_template('checkout.html', 
                          cart_items=cart_items, 
                          total_price=total_price,
                          order_id=order_id)
                          
@app.route('/create-checkout-session', methods=['POST'])
def create_checkout_session():
    if 'user' not in session or 'user_id' not in session:
        flash('Please login to checkout.', 'warning')
        return redirect(url_for('login'))
    
    if 'cart' not in session or not session['cart']:
        flash('Your cart is empty.', 'warning')
        return redirect(url_for('cart'))
    
    # Get the order details
    order_id = request.form.get('order_id')
    name = request.form.get('name')
    email = request.form.get('email')
    address = request.form.get('address')
    
    # Save these details in the session for later use
    session['checkout_details'] = {
        'order_id': order_id,
        'name': name,
        'email': email,
        'address': address
    }
    
    # Get cart items for line items
    line_items = []
    for item_id in session['cart']:
        product = Product.query.get(item_id)
        if product:
            line_items.append({
                'price_data': {
                    'currency': 'usd',
                    'product_data': {
                        'name': product.name,
                        'description': product.description or '',
                    },
                    'unit_amount': int(product.price * 100),  # Stripe uses cents
                },
                'quantity': 1,
            })
    
    YOUR_DOMAIN = request.host_url.rstrip('/')
    
    try:
        # Create Stripe checkout session
        checkout_session = stripe.checkout.Session.create(
            payment_method_types=['card'],
            line_items=line_items,
            mode='payment',
            success_url=YOUR_DOMAIN + url_for('payment_success'),
            cancel_url=YOUR_DOMAIN + url_for('payment_cancel'),
            customer_email=email,
        )
        
        # Store the session ID for later verification
        session['stripe_session_id'] = checkout_session.id
        session.modified = True
        
        # Redirect to Stripe's hosted checkout page
        return redirect(checkout_session.url, code=303)
    
    except Exception as e:
        app.logger.error(f"Error creating Stripe session: {str(e)}")
        flash('Error processing payment. Please try again.', 'danger')
        return redirect(url_for('checkout'))

@app.route('/place_order', methods=['POST'])
def place_order():
    if 'user' not in session or 'user_id' not in session:
        flash('Please login to place an order.', 'warning')
        return redirect(url_for('login'))
    
    if 'cart' not in session or not session['cart']:
        flash('Your cart is empty.', 'warning')
        return redirect(url_for('cart'))
    
    order_id = request.form.get('order_id')
    name = request.form.get('name')
    email = request.form.get('email')
    address = request.form.get('address')
    payment_method = request.form.get('payment_method')
    total_price = float(request.form.get('total_price', 0))
    
    # Create the order
    order = Order(
        order_id=order_id,
        user_id=session['user_id'],
        name=name,
        email=email,
        address=address,
        payment_method=payment_method,
        total_price=total_price,
        status="pending"
    )
    db.session.add(order)
    db.session.commit()
    
    # Add order items
    for item_id in session['cart']:
        product = Product.query.get(item_id)
        if product:
            order_item = OrderItem(
                order_id=order.id,
                product_id=product.id,
                price=product.price,
                quantity=1
            )
            db.session.add(order_item)
    
    db.session.commit()
    
    # Clear the cart
    session.pop('cart', None)
    
    flash('Order placed successfully!', 'success')
    return redirect(url_for('confirmation', order_id=order_id))

@app.route('/payment_success')
def payment_success():
    # Verify the session was completed successfully
    if 'stripe_session_id' in session and 'checkout_details' in session:
        stripe_session_id = session.pop('stripe_session_id', None)
        checkout_details = session.pop('checkout_details', {})
        
        try:
            # Get the session from Stripe to verify payment
            checkout_session = stripe.checkout.Session.retrieve(stripe_session_id)
            
            if checkout_session.payment_status == 'paid':
                # Create the order in our database
                order_id = checkout_details.get('order_id', generate_order_id())
                name = checkout_details.get('name', '')
                email = checkout_details.get('email', '')
                address = checkout_details.get('address', '')
                
                # Calculate total price from cart
                total_price = 0
                for item_id in session.get('cart', []):
                    product = Product.query.get(item_id)
                    if product:
                        total_price += product.price
                
                # Create the order
                order = Order(
                    order_id=order_id,
                    user_id=session['user_id'],
                    name=name,
                    email=email,
                    address=address,
                    payment_method="Credit Card (Stripe)",
                    total_price=total_price,
                    status="paid"  # Mark as paid since Stripe confirmed payment
                )
                db.session.add(order)
                db.session.commit()
                
                # Add order items
                for item_id in session.get('cart', []):
                    product = Product.query.get(item_id)
                    if product:
                        order_item = OrderItem(
                            order_id=order.id,
                            product_id=product.id,
                            price=product.price,
                            quantity=1
                        )
                        db.session.add(order_item)
                
                db.session.commit()
                
                # Clear the cart
                session.pop('cart', None)
                
                flash('Payment successful! Your order has been placed.', 'success')
                return redirect(url_for('confirmation', order_id=order_id))
            else:
                flash('Payment was not completed. Please try again.', 'warning')
                return redirect(url_for('checkout'))
                
        except Exception as e:
            app.logger.error(f"Error verifying Stripe payment: {str(e)}")
            flash('Error processing payment. Please contact support.', 'danger')
            return redirect(url_for('checkout'))
    
    flash('Invalid payment session. Please try again.', 'warning')
    return redirect(url_for('checkout'))

@app.route('/payment_cancel')
def payment_cancel():
    flash('Payment was cancelled. Please try again when you\'re ready.', 'warning')
    return redirect(url_for('checkout'))

@app.route('/confirmation')
def confirmation():
    order_id = request.args.get('order_id')
    order = Order.query.filter_by(order_id=order_id).first()
    
    if not order:
        flash('Order not found.', 'danger')
        return redirect(url_for('dashboard'))
    
    return render_template('confirmation.html', order=order, order_id=order_id)

@app.route('/contactus', methods=['GET', 'POST'])
def contactus():
    if request.method == 'POST':
        # For demonstration, we'll just show a flash message
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')
        
        # In a real application, you would store this in a database or send an email
        flash('Thank you for your message! We will get back to you soon.', 'success')
        return redirect(url_for('contactus'))
    
    return render_template('contactus.html')

# Error Handlers
@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(error):
    return render_template('500.html', error_id=str(uuid.uuid4()), now=datetime.datetime.now()), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)